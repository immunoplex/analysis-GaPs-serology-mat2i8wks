drop table if exists dbo.[SearchQueries]

	--saved user created scripts to search in the central database
	--updated 7/2 to include missing column for query type
	CREATE TABLE [dbo].[SearchQueries](
		[Id] [int] IDENTITY(1,1) NOT NULL,
		[QueryName] [varchar](50) NULL,
		[QuerySql] [varchar](max) NULL,
		[UserId] [varchar](20) NULL,
		[QueryType] [varchar](50) NULL
	) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

