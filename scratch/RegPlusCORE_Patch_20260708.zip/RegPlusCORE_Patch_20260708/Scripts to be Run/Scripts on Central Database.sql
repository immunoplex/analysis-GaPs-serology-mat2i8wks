--Run this script on your central database
alter table file_registration alter column [filename] nvarchar(1000)